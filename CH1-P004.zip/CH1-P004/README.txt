SBL 1.0 resolved page rendering package
Render target: CH1-P004
Entry file: CH1-P004.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-age11-character-reference-sheet.png
  Assets/Manga Me Character Sheet.png
  Assets/Haru-character-sheet.png
  Assets/Emi-character-Sheet.png
  Assets/SRA-production-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
